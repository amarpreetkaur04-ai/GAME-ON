(() => {
    var n = {
            575: e => {
                e.exports = function(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }, e.exports.default = e.exports, e.exports.__esModule = !0
            },
            913: e => {
                function i(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var i = t[n];
                        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
                    }
                }
                e.exports = function(e, t, n) {
                    return t && i(e.prototype, t), n && i(e, n), e
                }, e.exports.default = e.exports, e.exports.__esModule = !0
            },
            719: (e, t, n) => {
                var i = n(575),
                    n = function() {
                        "use strict";
                        return function e() {
                            var t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
                            i(this, e), this.id = t.id || null, this.title = t.title || null, this.text = t.text || null, this.list = t.list || [], this.image = t.image || null, this.actionItem = t.actionItem || !1
                        }
                    }();
                e.exports = n
            },
            233: (e, t, n) => {
                var i = n(575),
                    n = function() {
                        "use strict";
                        return function e() {
                            var t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
                            i(this, e), this.design = t.design || null, this.selectedLayout = t.selectedLayout || null
                        }
                    }();
                e.exports = n
            },
            84: (e, t, n) => {
                var o = n(575),
                    a = n(913),
                    l = n(719),
                    n = function() {
                        "use strict";

                        function i() {
                            o(this, i)
                        }
                        return a(i, null, [{
                            key: "TAG",
                            get: function() {
                                return "schema"
                            }
                        }, {
                            key: "get",
                            value: function(n) {
                                buildfire.datastore.get(i.TAG, function(e, t) {
                                    return e ? n(e) : 0 === Object.keys(t.data).length ? n(null, null) : n(null, new l(t.data))
                                })
                            }
                        }, {
                            key: "save",
                            value: function(e, n) {
                                buildfire.datastore.save(e, i.TAG, function(e, t) {
                                    return e ? n(e) : n(null, new l(t.data))
                                })
                            }
                        }, {
                            key: "onUpdate",
                            value: function(t) {
                                buildfire.datastore.onUpdate(function(e) {
                                    if (e && e.tag == i.TAG) return t(e, null)
                                })
                            }
                        }]), i
                    }();
                e.exports = n
            },
            737: (e, t, n) => {
                var i = n(575),
                    o = n(913),
                    a = n(233),
                    n = function() {
                        "use strict";

                        function t() {
                            i(this, t)
                        }
                        return o(t, null, [{
                            key: "TAG",
                            get: function() {
                                return "Settings"
                            }
                        }, {
                            key: "get",
                            value: function(n) {
                                buildfire.datastore.get(t.TAG, function(e, t) {
                                    return e ? n(e) : 0 === Object.keys(t.data).length ? n(null, null) : n(null, new a(t.data))
                                })
                            }
                        }, {
                            key: "save",
                            value: function(e, n) {
                                buildfire.datastore.save({
                                    $set: e
                                }, t.TAG, function(e, t) {
                                    return e ? n(e) : n(null, new a(t.data))
                                })
                            }
                        }]), t
                    }();
                e.exports = n
            },
            638: e => {
                "use strict";
                e.exports = buildfire
            }
        },
        i = {};

    function h(e) {
        var t = i[e];
        if (void 0 !== t) return t.exports;
        t = i[e] = {
            exports: {}
        };
        return n[e](t, t.exports, h), t.exports
    }(() => {
        var o, s = h(638),
            e = h(84),
            r = h(737),
            a = [],
            c = null,
            t = !0,
            n = s.getContext().instanceId;

        function u(e) {
            var t, n;
            widgetContent.style.opacity = 0, Array.isArray(e.list) && (p(), text.innerHTML = e.text || "", text.style.display = e.text ? "block" : "none", links.innerHTML = "", links.className = "item-list" + (e.text ? "" : " safe-padding"), e.list.forEach(function(e) {
                var t = function(e, t) {
                    e = document.createElement(e);
                    return t.appendChild(e), e
                }("div", links, e.title);
                t.className = "list-item";
                var n = document.createElement("span");
                n.innerHTML = e.title, n.className = "ellipsis list-item-title bodyTextTheme", t.appendChild(n);
                var i = document.createElement("div");
                i.className = "list-item-img-container";
                var o, a, l = null;
                e.image && ("string" == typeof e.image ? l = e.image : e.image.iconUrl ? l = e.image.iconUrl : e.image.iconClassName && (l = e.image.iconClassName)), !l && e.actionItem && (e.actionItem.iconUrl ? l = e.actionItem.iconUrl : e.actionItem.iconClassName && (l = e.actionItem.iconClassName)), (l = l || "glyphicon glyphicon-picture") && l.indexOf("http") < 0 ? ((n = document.createElement("span")).className = "list-item-icon icon-custom-style " + l, i.appendChild(n)) : l && (a = document.createElement("img"), r.get(function(e, t) {
                    if (e) return console.error(e);
                    c = t;
                    t = y();
                    o = "RESIZE" === t ? s.imageLib.resizeImage(l, {
                        size: "xxl",
                        aspect: "16:9"
                    }) : s.imageLib.cropImage(l, {
                        size: "m",
                        aspect: "1:1"
                    }), a.src = o, a.className = "list-item-img", i.appendChild(a), g()
                })), t.appendChild(i), t.onclick = function() {
                    f("openLevel"), e.list ? (d(e, !0), s.analytics.trackView(e.id, {
                        eventTitle: e.title,
                        _buildfire: {
                            aggregationValue: 1
                        }
                    }), u(e)) : e.actionItem && (s.analytics.trackAction(e.id, {
                        eventTitle: e.title,
                        _buildfire: {
                            aggregationValue: 1
                        }
                    }), s.actionItems.execute(e.actionItem))
                }
            }), t = document.getElementById("emptyPageState"), n = document.getElementById("links"), 0 !== e.list.length || e.text ? (t.classList.add("hidden"), n.classList.remove("hidden")) : (t.classList.remove("hidden"), n.classList.add("hidden")), widgetContent.style.opacity = 1), m()
        }

        function d(e, t) {
            1 < arguments.length && void 0 !== t && t && s.messaging.sendMessageToControl({
                level: e
            }), s.history.push(e.title, {
                level: e,
                showLabelInTitlebar: !0
            }), a.push(e)
        }
        window.onload = function() {
            function n(e) {
                document.documentElement.style.setProperty("--color", e.colors.bodyText), document.documentElement.style.setProperty("--backgroundColor", e.colors.backgroundColor), document.documentElement.style.setProperty("--defaultBGColor", e.colors.primaryTheme), p()
            }
            s.spinner.show(), s._cssInjection.onUpdate(function() {
                a.length && a[a.length - 1] && a[a.length - 1].list.length ? u(a[a.length - 1]) : o && o.list.length && u(o)
            }, !0), s.appearance.getAppTheme(function(e, t) {
                return e ? console.error(e) : void n(t)
            }), s.appearance.onUpdate(function(e) {
                n(e)
            }), e.get(function(e, t) {
                e ? console.error(e) : t ? (o = t, s.spinner.hide(), u(t)) : (s.spinner.hide(), document.body.classList.add("bitmap"), widgetContent.style.display = "none")
            }), e.onUpdate(function(e) {
                o = e.data, "none" === widgetContent.style.display && (widgetContent.style.display = "block"), document.body.classList.remove("bitmap")
            })
        }, s.navigation.onAppLauncherActive(function() {
            s.history.get({
                pluginBreadcrumbsOnly: !1
            }, function(e, t) {
                a.length > t.length - 1 && a.map(function(e) {
                    return s.history.push(e.title, {
                        level: e
                    })
                })
            }), m()
        }, !1);
        var i = s.navigation.onBackButtonClick;
        s.navigation.onBackButtonClick = function() {
            0 === a.length ? i() : (s.history.pop(), a.pop(), s.history.get({
                pluginBreadcrumbsOnly: !0
            }, function(e, t) {
                0 === t.length ? (s.messaging.sendMessageToControl({
                    level: o
                }), u(o)) : 0 < t.length && (s.messaging.sendMessageToControl({
                    level: t[t.length - 1].options.level
                }), u(t[t.length - 1].options.level)), f("backButton")
            }))
        }, s.messaging.onReceivedMessage = function(i) {
            if (!i.instanceId || i.instanceId === n) {
                if (i.firstTime && u(o), i.update ? (i.update.actionItem && (i.update = i.parent), "none" === widgetContent.style.display && (widgetContent.style.display = "block"), document.body.classList.remove("bitmap"), u(i.update), s.history.get({
                        pluginBreadcrumbsOnly: !0
                    }, function(e, t) {
                        for (var n = t.length - 1; n <= t.length; n++) s.history.pop(), a.pop();
                        0 !== t.length && (JSON.stringify(i.parent) !== JSON.stringify(o) && d(i.parent, !1), d(i.update, !1))
                    })) : i.level ? (d(i.level, !1), u(i.level)) : i.goBack && s.history.get({
                        pluginBreadcrumbsOnly: !0
                    }, function(e, t) {
                        if ("home" === i.goBack) l(t);
                        else {
                            for (var n = t.findIndex(function(e) {
                                    return e.options.level.title === i.goBack.title
                                }) + 1; n <= t.length; n++) void 0 !== t[n] && (s.history.pop(), a.pop());
                            u(a[a.length - 1])
                        }
                    }), i.settings) return c = i.settings, void g();
                i.resetBreadcrumbs && a.length && l(a), i.syncBreadcrumbs && setTimeout(function() {
                    s.messaging.sendMessageToControl({
                        breadcrumbs: a
                    })
                }, 0), i.reload && window.location.reload()
            }
        };
        var l = function(e) {
                for (var t = e.length, n = 0; n <= t; n++) s.history.pop(), a.pop();
                u(o)
            },
            g = function() {
                var e = document.getElementById("widgetContent"),
                    t = document.getElementById("backgroundColorDiv");
                c && c.design && c.design.backgroundCSS && c.design.background && c.design.background.gradient ? "gradient" === c.design.background.colorType ? t.style.background = c.design.background.gradient.backgroundCSSValue : t.style.backgroundColor = c.design.background.solid.color : t.style.background = "", window.innerWidth < 640 ? c && c.design && c.design.mobileBackground && c.design.mobileBackground.src ? (e.style.backgroundImage = "url(".concat(c.design.mobileBackground.src, ")"), e.style.backgroundSize = c.design.mobileBackground.backgroundSize) : e.style.background = "" : c && c.design && c.design.tabletBackground && c.design.tabletBackground.src ? (e.style.backgroundImage = "url(".concat(c.design.tabletBackground.src, ")"), e.style.backgroundSize = c.design.tabletBackground.backgroundSize) : e.style.background = "", m()
            },
            p = function() {
                c ? g() : r.get(function(e, t) {
                    e && console.error(e), c = t || {
                        design: {
                            showTitleBar: !0
                        }
                    }, g()
                })
            },
            m = function() {
                setTimeout(function() {
                    0 === a.length && c && c.design && !1 === c.design.showTitleBar ? (t = !0, s.appearance.titlebar.hide(), widgetContent.classList.add("safe-area")) : t && (t = !1, s.appearance.titlebar.show(), widgetContent.classList.remove("safe-area"))
                }, 0)
            },
            f = function(e) {
                var t = document.getElementById("backgroundColorDiv");
                if (t) switch (e) {
                    case "backButton":
                        t.scrollTo({
                            top: t.scrollHeight
                        });
                        break;
                    case "openLevel":
                        t.scrollTo({
                            top: 0
                        })
                }
            },
            y = function() {
                var e = (c.design && c.design.selectedLayout ? c.design : c).selectedLayout;
                if (e) {
                    e = e.originalLayoutName || e.name;
                    return "Layout 2" === e || "Layout 7" === e ? "RESIZE" : "CROP"
                }
                return null
            }
    })()
})();