/**/
typeof angular.callbacks._0 === 'function' && angular.callbacks._0({
    "id": 1,
    "result": {
        "_id": "66da43a4b571dd03e8d5f2e1",
        "userId": "66da43a4b571dd03e8d5f2e1",
        "isActive": true,
        "imageUrl": "https://lh3.googleusercontent.com/a-/ALV-UjV8I1EDmSFihaYCzxH6Ghrm75qzGEIOrKt3AXWekfJZp8-CmAppU9fZrtdmBS2A-pCjfWE-TcVslwJOtcBZntE54jP-NooH4Cyc6oMm3_16hKrxvZodJ0Kr3fkWySbt7igS35naHrxzAJUc2i0YV2VHq-dAKVbiE7UleAyJ7ONTz-atDcKJi_ESmGBNiV5kZoj7ps01sLBzo5Qi7G8mydt73Qv8rjritfJjwwcqFtXOSJWOSmpKVmgnC8pGzNGi7bTwTWioynZFmHVvFWfvlGtBHOUe21QsBC8v4JHa4xUjeN5INFCO0eICVwqpgpNPD_-aG7bnrcg8h6ez9c1c3ZJnao7nF2Lhcdh7pmuUPPHyQdGAlrFBNl0qGoZCv8eARFty0uMXgzNOZ-ZwmBZTEZObtknDCcJkWfzjEjGhwehJvIodTo9minF91Jkhb1qxDEWyz6wpjmbZli4JgzxQ3x-mcHYuEYsqzBYAjHWXIlzWrukSJPJNaX0jIRS_HtCd5Dx7AT_X2lHqlNicWWllb_kIvDyjHcGn3bavFaffvNrgAWOj0wg3M8VKeD6LeXxHX2COlUgRVJrvnXSEujHUlZTw6XvfjCBjZ8H-Ot5NnzgXjBrBt0c2tShoHSsxZk26W43Sh1xOMiy0MqVE3YNJ0NKmvCFtu238dZCjZySRqNUc1co53r1Sv6ra8wQBiiNM_kAumkKE93b5DeeIXtuCmBKYinaUObfi7V_mVqTzWMNtmP_4XOVWAHAWlMudHH0-KG3RFRL4Mp8hIEldFSz8XAdd_nY1_9Jhc4yrKGJYVaHAEAV_PAKpN4OJa_VVlyEvzWNzszJLrMYE-0M4IulL7CX6v9PfzWMyKM5LGEBVPa4JB5XvGWlQ_EU2JkwgscN43W7Z3NcnYiyCvx-bFCGUWaJe-oHE2Ty2UmYKVuGk0G3zTn7n0DQhtCXRwo1Du4rlF6jM7KC7UH4VP6rE9kR_ucfApjlN=s96-c",
        "displayName": "Amarpreet Kaur",
        "lastName": "Kaur",
        "username": "amarpreet2210kaur@gmail.com",
        "firstName": "Amarpreet",
        "email": "amarpreet2210kaur@gmail.com",
        "createdOn": "2024-09-05T23:49:56.316Z",
        "failedAttemptCount": 0,
        "lastAccess": "2024-09-06T06:10:17.321Z",
        "lastActive": "2024-09-06T06:37:33.360Z",
        "lastUpdated": "2024-09-06T06:35:30.050Z",
        "loginProviderType": "google",
        "oauthProfile": {
            "providerId": "google",
            "accessToken": "ya29.a0AcM612zqIwLO4AgeQWup1WIiI-gJBjFEy_fNHlb0VUbig7QtGgGtEav-3p2iwt37LYsbEN-Dz3iWS72uXs9De6Hp_fvzPSv9g5XlRV8thGWk8ixxiarwTvUsAS-1GneX_Y-CWEVvREz1f_vIBZApXwz8g4zZMTJiAZwaCgYKAWoSARESFQHGX2MiGCx2HyKwjM_Hoe_dM7EH7w0170",
            "expiresIn": 3599,
            "tokenType": "Bearer",
            "userInfo": {
                "sub": "104062259700402693148",
                "name": "Amarpreet Kaur",
                "given_name": "Amarpreet",
                "family_name": "Kaur",
                "picture": "https://lh3.googleusercontent.com/a-/ALV-UjV8I1EDmSFihaYCzxH6Ghrm75qzGEIOrKt3AXWekfJZp8-CmAppU9fZrtdmBS2A-pCjfWE-TcVslwJOtcBZntE54jP-NooH4Cyc6oMm3_16hKrxvZodJ0Kr3fkWySbt7igS35naHrxzAJUc2i0YV2VHq-dAKVbiE7UleAyJ7ONTz-atDcKJi_ESmGBNiV5kZoj7ps01sLBzo5Qi7G8mydt73Qv8rjritfJjwwcqFtXOSJWOSmpKVmgnC8pGzNGi7bTwTWioynZFmHVvFWfvlGtBHOUe21QsBC8v4JHa4xUjeN5INFCO0eICVwqpgpNPD_-aG7bnrcg8h6ez9c1c3ZJnao7nF2Lhcdh7pmuUPPHyQdGAlrFBNl0qGoZCv8eARFty0uMXgzNOZ-ZwmBZTEZObtknDCcJkWfzjEjGhwehJvIodTo9minF91Jkhb1qxDEWyz6wpjmbZli4JgzxQ3x-mcHYuEYsqzBYAjHWXIlzWrukSJPJNaX0jIRS_HtCd5Dx7AT_X2lHqlNicWWllb_kIvDyjHcGn3bavFaffvNrgAWOj0wg3M8VKeD6LeXxHX2COlUgRVJrvnXSEujHUlZTw6XvfjCBjZ8H-Ot5NnzgXjBrBt0c2tShoHSsxZk26W43Sh1xOMiy0MqVE3YNJ0NKmvCFtu238dZCjZySRqNUc1co53r1Sv6ra8wQBiiNM_kAumkKE93b5DeeIXtuCmBKYinaUObfi7V_mVqTzWMNtmP_4XOVWAHAWlMudHH0-KG3RFRL4Mp8hIEldFSz8XAdd_nY1_9Jhc4yrKGJYVaHAEAV_PAKpN4OJa_VVlyEvzWNzszJLrMYE-0M4IulL7CX6v9PfzWMyKM5LGEBVPa4JB5XvGWlQ_EU2JkwgscN43W7Z3NcnYiyCvx-bFCGUWaJe-oHE2Ty2UmYKVuGk0G3zTn7n0DQhtCXRwo1Du4rlF6jM7KC7UH4VP6rE9kR_ucfApjlN=s96-c",
                "email": "amarpreet2210kaur@gmail.com",
                "email_verified": true
            },
            "codeChallengeData": {
                "codeVerifier": null,
                "codeChallenge": null,
                "codeChallengeMethod": null
            },
            "predefiendLogin": true
        },
        "accessToken": "b5wpBAFu3B4UkSkjv7NTIXeFbCSpPYunG3wQYQgoqzI=",
        "accessTokenExpiresIn": "2026-09-05T00:00:00.000Z",
        "externalApps": {
            "2f0b9d18-6be1-11ef-a97f-12565309935d": {
                "externalAppId": "2f0b9d18-6be1-11ef-a97f-12565309935d"
            }
        },
        "userProfile": {
            "hideEmail": true
        },
        "userToken": "nKwCsiBJk7QL7CAg/cOTbYmg2UnJCaGdY/kiwsDeCUQ="
    }
});