console.log("remote Operation File Loaded");
window.remoteOperationsLoaded = true;
// Handle false negatives for onLine status
// app can't be offline since this file loaded from network
if (typeof(navigator) != "undefined") {
    if (navigator.connection && navigator.connection.type && navigator.connection.type == "none") {
        window.ignoreNavigatorOnline = true;
    } else if (typeof(navigator.onLine) != "undefined" && !navigator.onLine) {
        window.ignoreNavigatorOnline = true;
    }
}