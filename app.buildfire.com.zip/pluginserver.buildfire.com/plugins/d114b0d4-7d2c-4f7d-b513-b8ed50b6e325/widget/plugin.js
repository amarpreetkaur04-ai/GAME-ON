var pluginJson = {
    "author": "BuildFire",
    "pluginName": "Outline Action Item Folder",
    "pluginDescription": "Creating an outline holding app structure, you can create and assign new pages to different sections, add action items as endpoints. All sections can be completely customized with images/icons or by using WYSIWYG editor.",
    "supportEmail": "support@buildfire.com",
    "control": {
        "content": {
            "enabled": true
        },
        "design": {
            "enabled": true
        },
        "settings": {
            "enabled": false
        },
        "cssInjection": {
            "enabled": true,
            "layouts": [{
                "name": "Layout 1",
                "imageUrl": "resources/layouts_img/layout1.png",
                "cssPath": "widget/layouts/layout1.css"
            }, {
                "name": "Layout 2",
                "imageUrl": "resources/layouts_img/layout2.png",
                "cssPath": "widget/layouts/layout2.css"
            }, {
                "name": "Layout 3",
                "imageUrl": "resources/layouts_img/layout3.png",
                "cssPath": "widget/layouts/layout3.css"
            }, {
                "name": "Layout 4",
                "imageUrl": "resources/layouts_img/layout4.png",
                "cssPath": "widget/layouts/layout4.css"
            }, {
                "name": "Layout 5",
                "imageUrl": "resources/layouts_img/layout5.png",
                "cssPath": "widget/layouts/layout5.css"
            }, {
                "name": "Layout 6",
                "imageUrl": "resources/layouts_img/layout6.png",
                "cssPath": "widget/layouts/layout6.css"
            }, {
                "name": "Layout 7",
                "imageUrl": "resources/layouts_img/layout7.png",
                "cssPath": "widget/layouts/layout7.css"
            }, {
                "name": "Layout 8",
                "imageUrl": "resources/layouts_img/layout8.png",
                "cssPath": "widget/layouts/layout8.css"
            }, {
                "name": "Layout 9",
                "imageUrl": "resources/layouts_img/layout9.png",
                "cssPath": "widget/layouts/layout9.css"
            }, {
                "name": "Layout 10",
                "imageUrl": "resources/layouts_img/layout10.png",
                "cssPath": "widget/layouts/layout10.css"
            }, {
                "name": "Layout 11",
                "imageUrl": "resources/layouts_img/layout11.png",
                "cssPath": "widget/layouts/layout11.css"
            }, {
                "name": "Layout 12",
                "imageUrl": "resources/layouts_img/layout12.png",
                "cssPath": "widget/layouts/layout12.css"
            }, {
                "name": "Layout 13",
                "imageUrl": "resources/layouts_img/layout13.png",
                "cssPath": "widget/layouts/layout13.css"
            }, {
                "name": "Layout 14",
                "imageUrl": "resources/layouts_img/layout14.png",
                "cssPath": "widget/layouts/layout14.css"
            }, {
                "name": "Layout 15",
                "imageUrl": "resources/layouts_img/layout15.png",
                "cssPath": "widget/layouts/layout15.css"
            }, {
                "name": "Layout 16",
                "imageUrl": "resources/layouts_img/layout16.png",
                "cssPath": "widget/layouts/layout16.css"
            }, {
                "name": "Layout 17",
                "imageUrl": "resources/layouts_img/layout17.png",
                "cssPath": "widget/layouts/layout17.css"
            }, {
                "name": "Layout 18",
                "imageUrl": "resources/layouts_img/layout18.png",
                "cssPath": "widget/layouts/layout18.css"
            }, {
                "name": "Layout 19",
                "imageUrl": "resources/layouts_img/layout19.png",
                "cssPath": "widget/layouts/layout19.css"
            }, {
                "name": "Layout 20",
                "imageUrl": "resources/layouts_img/layout20.png",
                "cssPath": "widget/layouts/layout20.css"
            }, {
                "name": "Layout 21",
                "imageUrl": "resources/layouts_img/layout21.png",
                "cssPath": "widget/layouts/layout21.css"
            }, {
                "name": "Layout 22",
                "imageUrl": "resources/layouts_img/layout22.png",
                "cssPath": "widget/layouts/layout22.css"
            }, {
                "name": "Layout 23",
                "imageUrl": "resources/layouts_img/layout23.png",
                "cssPath": "widget/layouts/layout23.css"
            }, {
                "name": "Layout 24",
                "imageUrl": "resources/layouts_img/layout24.png",
                "cssPath": "widget/layouts/layout24.css"
            }, {
                "name": "Layout 25",
                "imageUrl": "resources/layouts_img/layout25.png",
                "cssPath": "widget/layouts/layout25.css"
            }, {
                "name": "Layout 26",
                "imageUrl": "resources/layouts_img/layout26.png",
                "cssPath": "widget/layouts/layout26.css"
            }, {
                "name": "Layout 27",
                "imageUrl": "resources/layouts_img/layout27.png",
                "cssPath": "widget/layouts/layout27.css"
            }, {
                "name": "Layout 28",
                "imageUrl": "resources/layouts_img/layout28.png",
                "cssPath": "widget/layouts/layout28.css"
            }],
            "customLayoutsTag": "$$layouts",
            "activeLayoutTag": "Settings"
        },
        "customTabs": [{
            "title": "Tests",
            "url": "/tests/index.html"
        }]
    },
    "widget": {},
    "features": [],
    "webpack": "8080",
    "languages": ["en"]
};
if (buildfire.onPluginJsonLoaded) {
    buildfire.onPluginJsonLoaded(pluginJson);
}