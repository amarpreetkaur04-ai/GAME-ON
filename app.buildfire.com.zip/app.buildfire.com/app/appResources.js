"use strict";
window._appRoot = window._appRoot || "", window.parseQueryString = function() {
    for (var n = location.search.substring(1).split("&"), o = new Object, r = 0; r < n.length; r++) {
        var t = n[r].split("=");
        o[decodeURIComponent(t[0])] = decodeURIComponent(t[1])
    }
    return o
};
var qs = window.parseQueryString();
window._getAppId = function() {
        var n = null;
        return qs && qs.appId ? n = qs.appId : window.appProxy && window.appProxy.currentApp && window.appProxy.currentApp.appId && (n = window.appProxy.currentApp.appId), window.currentAppId = n, n
    }, window._getAppMode = function() {
        var n = null;
        return qs && qs.mode ? n = qs.mode : window.appProxy && (n = window.appProxy.mode), n
    }, window._getEnv = function() {
        var n = null;
        return qs && qs.env ? n = qs.env : window.appProxy && (n = window.appProxy.env), n
    }, window._isPreview = function() {
        var n = null;
        return qs && qs.preview ? n = qs.preview : window.appProxy && (n = window.appProxy.preview), n
    }, window._isTest = function() {
        var n = !1;
        return qs && qs.test ? n = "true" === qs.test : window.appProxy && (n = "true" === window.appProxy.test), n
    }, window._getLastUrl = function() {
        var n = null;
        return qs && qs.lastUrl ? n = qs.lastUrl : window.appProxy && (n = window.appProxy.lastUrl), n
    }, window._getTrack = function() {
        var n = null;
        return qs && qs.track ? n = qs.track : window.appProxy && (n = window.appProxy.track), n
    }, window._getWidth = function() {
        var n = null;
        return qs && qs.width ? n = qs.width : window.appProxy && (n = window.appProxy.width), n
    },
    function() {
        if (window._getAppId(), void 0 === n) {
            var n = function(n, o) {
                o = o || {
                    bubbles: !1,
                    cancelable: !1,
                    detail: void 0
                };
                var r = document.createEvent("CustomEvent");
                return r.initCustomEvent(n, o.bubbles, o.cancelable, o.detail), r
            };
            n.prototype = window.Event.prototype, window.CustomEvent = n
        }
    }();
"use strict";
var loadjs = function() {
    var e = function() {},
        s = {},
        t = {},
        r = {};

    function i(e, s) {
        if (e) {
            var i = r[e];
            if (t[e] = s, i)
                for (; i.length;) i[0](e, s), i.splice(0, 1)
        }
    }

    function o(s, t) {
        s.call && (s = {
            success: s
        }), t.length ? (s.error || e)(t) : (s.success || e)(s)
    }

    function n(s, t, r, i) {
        var o, a, p = document,
            c = r.async,
            l = (r.numRetries || 0) + 1,
            u = r.before || e,
            f = s.replace(/[\?|#].*$/, ""),
            d = s.replace(/^(css|img)!/, "");
        i = i || 0, /(^css!|\.css$)/.test(f) ? ((a = p.createElement("link")).rel = "stylesheet", a.href = d, (o = "hideFocus" in a) && a.relList && (o = 0, a.rel = "preload", a.as = "style")) : /(^img!|\.(png|gif|jpg|svg|webp)$)/.test(f) ? (a = p.createElement("img")).src = d : ((a = p.createElement("script")).src = s, a.async = void 0 === c || c), a.onload = a.onerror = a.onbeforeload = function(e) {
            var p = e.type[0];
            if (o) try {
                a.sheet.cssText.length || (p = "e")
            } catch (e) {
                18 != e.code && (p = "e")
            }
            if ("e" == p) {
                if ((i += 1) < l) return n(s, t, r, i)
            } else if ("preload" == a.rel && "style" == a.as) return a.rel = "stylesheet";
            t(s, p, e.defaultPrevented)
        }, !1 !== u(s, a) && p.head.appendChild(a)
    }

    function a(e, t, r) {
        var a, p;
        if (t && t.trim && (a = t), p = (a ? r : t) || {}, a) {
            if (a in s) throw "LoadJS";
            s[a] = !0
        }

        function c(s, t) {
            ! function(e, s, t) {
                var r, i, o = (e = e.push ? e : [e]).length,
                    a = o,
                    p = [];
                for (r = function(e, t, r) {
                        if ("e" == t && p.push(e), "b" == t) {
                            if (!r) return;
                            p.push(e)
                        }--o || s(p)
                    }, i = 0; i < a; i++) n(e[i], r, t)
            }(e, (function(e) {
                o(p, e), s && o({
                    success: s,
                    error: t
                }, e), i(a, e)
            }), p)
        }
        if (p.returnPromise) return new Promise(c);
        c()
    }
    return a.ready = function(e, s) {
        return function(e, s) {
            e = e.push ? e : [e];
            var i, o, n, a = [],
                p = e.length,
                c = p;
            for (i = function(e, t) {
                    t.length && a.push(e), --c || s(a)
                }; p--;) o = e[p], (n = t[o]) ? i(o, n) : (r[o] = r[o] || []).push(i)
        }(e, (function(e) {
            o(s, e)
        })), a
    }, a.done = function(e) {
        i(e, [])
    }, a.reset = function() {
        s = {}, t = {}, r = {}
    }, a.isDefined = function(e) {
        return e in s
    }, a
}();

function AppContext(e, s, t, r, i, o) {
    this.environment = s, this.liveMode = t, this.track = r, this.lastUrl = i, this.preview = o, this.currentApp = {
        appId: e,
        keys: {
            datastoreKey: "NO-STORE-KEY"
        }
    }, this.currentPlugin = null
}
AppContext.prototype = {
        load: function(e) {
            try {
                "undefined" != typeof siteConfig && window.siteConfig.endPoints && window.siteConfig.endPoints.appHost ? navigator.onLine ? this.setConfig(e) : (console.warn("offline: getting app settings form local storage"), this.setConfigLocal(e)) : setTimeout((function() {
                    window.appContext && window.appContext.load(e)
                }), 250)
            } catch (s) {
                this.setConfigLocal(e)
            }
        },
        setConfigLocal: function(e) {
            try {
                if (this.currentApp.config = JSON.parse(localStorage.getItem("currentApp" + this.currentApp.appId)), !this.currentApp.config) return void alert("App is not initialized");
                this.updateEndpointsWithOverrides(this.currentApp.config.overrideEndPoints), e && e()
            } catch (e) {
                alert("App is not initialized from storage"), console.error("cant JSON.parse from localStorage", e)
            }
        },
        setConfig: function(e) {
            var s = this,
                t = new XMLHttpRequest,
                r = Date.now();
            t.open("GET", window.siteConfig.endPoints.appHost + "/api/whitelabel/app/" + this.currentApp.appId + "/configuration?overrideEndPoints=true&mode=" + (window.appContext.liveMode || 0), !1), t.onreadystatechange = function() {
                var i;
                if (4 == t.readyState) {
                    if (200 === t.status) try {
                        (o = JSON.parse(t.responseText)).JSONConfig ? s.currentApp.config = JSON.parse(o.JSONConfig) : s.currentApp.config = {}, s.currentApp.config.cpDomain = o.cpDomain, s.currentApp.config.isActive = void 0 === o.isActive ? 1 : o.isActive, s.currentApp.config.isPaidApp = void 0 === o.isPaidApp ? 1 : o.isPaidApp, s.currentApp.config.wlAppHost = o.wlAppHost, s.currentApp.config.appPwaHost = o.appPwaHost, s.currentApp.config.appName = o.appName, s.currentApp.keys || (s.currentApp.keys = {}), o.intercomKey && (s.currentApp.keys.intercomKey = o.intercomKey), o.hasOwnProperty("overrideEndPoints") || (i = !0, window.alert("Endpoints are missing")), s.currentApp.config.overrideEndPoints = o.overrideEndPoints, s.updateEndpointsWithOverrides(o.overrideEndPoints), window._defaultAppApiKeys = o.defaultApiKeys, localStorage.setItem("currentApp" + s.currentApp.appId, JSON.stringify(s.currentApp.config)), e()
                    } catch (t) {
                        console.error("failed to load app config", t), console.warn("switching to local app config"), s.setConfigLocal(e)
                    } else {
                        if (400 === t.status) try {
                            var o;
                            if ("VALIDATION" === (o = JSON.parse(t.responseText)).code && "Invalid appId" === o.message) return void alert("Unable to find app")
                        } catch (e) {}
                        console.error("failed to get app config", {
                            status: t.status
                        }), console.warn("switching to local app config"), s.setConfigLocal(e)
                    }
                    console.log("config loaded at: ", new Date)
                }
                try {
                    var n = localStorage.getItem("$$performance_log");
                    if (!n) return;
                    var a = JSON.parse(n);
                    a.appConfigLoadStart = r, a.appConfigLoadEnd = Date.now(), i && (a.userInputInterrupted = !0), localStorage.setItem("$$performance_log", JSON.stringify(a))
                } catch (e) {
                    console.error("error parsing $$performance_log: ".concat(e))
                }
            }, t.send()
        },
        updateEndpointsWithOverrides: function(e) {
            if (e)
                for (var s in e) e.hasOwnProperty(s) && (window.siteConfig.endPoints[s] = e[s])
        }
    },
    function() {
        var e = "undefined" != typeof module && module.exports;
        if (!e) {
            var s = document.getElementsByTagName("html")[0];
            s.hasAttribute("ng-app") && "buildfire" === s.getAttribute("ng-app") && s.removeAttribute("ng-app")
        }
        var t = ["scripts/framework/httpClient.js", "scripts/framework/deepLinking.js", "scripts/framework/postMaster.js", "scripts/framework/userTags.js", "scripts/framework/inAppPurchase.js", "scripts/framework/bfUtils.js", "scripts/framework/atatusAPI.js", "scripts/framework/appState.js", "scripts/framework/validator.js", "scripts/framework/globalEvents.js", "scripts/framework/remoteDatastore.js", "scripts/framework/offlineDatastore.js", "app.js", "scripts/framework/pluginAPI/appearanceAPI.js", "scripts/framework/pluginAPI/datastoreAPI.js", "scripts/framework/appApiKeys.js", "scripts/framework/pluginAPI/userDatastoreAPI.js", "scripts/framework/pluginAPI/analyticsAPI.js", "scripts/framework/pluginAPI/authAPI.js", "scripts/framework/pluginAPI/geoAPI.js", "scripts/framework/pluginAPI/termsAPI.js", "scripts/framework/pluginAPI/inputAPI.js", "scripts/framework/pluginAPI/gifAPI.js", "scripts/framework/pluginAPI/notesAPI.js", "scripts/framework/pluginAPI/bookmarkAPI.js", "scripts/framework/pluginAPI/imagePreviewerAPI.js", "scripts/framework/pluginAPI/imageCacheAPI.js", "scripts/framework/pluginAPI/pluginAPI.js", "scripts/framework/pluginAPI/notificationsAPI.js", "scripts/framework/pluginAPI/publicDatastoreAPI.js", "scripts/framework/pluginAPI/appDatastoreAPI.js", "scripts/framework/pluginAPI/localStorageAPI.js", "scripts/framework/pluginAPI/historyAPI.js", "scripts/framework/pluginAPI/appAPI.js", "scripts/framework/pluginAPI/publicFilesAPI.js", "scripts/framework/pluginAPI/dialogAPI.js", "scripts/framework/pluginAPI/searchEngineAPI.js", "scripts/framework/pluginAPI/creditsAPI.js", "scripts/framework/pluginAPI/stripeAPI.js", "scripts/framework/pluginAPI/deepLinkAPI.js", "scripts/framework/pluginAPI/shortLinksAPI.js", "scripts/framework/pluginAPI/userTagsAPI.js", "scripts/framework/pluginAPI/iBeaconAPI.js", "scripts/framework/pluginAPI/barcodeScannerAPI.js", "scripts/framework/pluginAPI/fileManagerAPI.js", "scripts/framework/pluginAPI/deviceAPI.js", "scripts/framework/pluginAPI/previewerAPI.js", "scripts/framework/pluginAPI/bluetoothAPI.js", "scripts/framework/pluginAPI/BleCentralAPI.js", "scripts/framework/pluginAPI/localNotificationsAPI.js", "scripts/framework/pluginAPI/pushNotificationsAPI.js", "scripts/framework/pluginAPI/pluginInstanceAPI.js", "scripts/framework/pluginAPI/inAppPurchaseAPI.js", "scripts/framework/pluginAPI/permissionRequestsAPI.js", "scripts/framework/pluginAPI/diagnosticsAPI.js", "scripts/framework/pluginAPI/healthAPI.js", "scripts/framework/pluginAPI/reportAbuseAPI.js", "scripts/framework/pluginAPI/aiAPI.js", "scripts/framework/pluginAPI/loggerAPI.js", "scripts/framework/cpSync.js", "scripts/framework/imageTools.js", "scripts/framework/loginUI.js", "scripts/framework/menuUI.js", "scripts/framework/customRegistration.js", "scripts/framework/onboardingUI.js", "scripts/framework/sliderUI.js", "scripts/framework/carouselUI.js", "scripts/framework/devModeUI.js", "pages/controllers/fauxHttpCtrl.js", "pages/controllers/launcherCtrl.js", "pages/controllers/pluginContainerCtrl.js", "pages/controllers/pushSubscriptionsCtrl.js", "scripts/framework/pluginAPI/actionItemsAPI.js", "pages/controllers/menuCtrl.js", "pages/controllers/authCtrl.js", "pages/controllers/popUpCtrl.js", "pages/controllers/servicesCtrl.js", "pages/controllers/accessCodeCtrl.js", "pages/controllers/gdprCtrl.js", "scripts/framework/modalCtrl.js", "pages/controllers/footerMenuCtrl.js", "pages/controllers/pwaPopupCtrl.js", "pages/controllers/gdprPopupCtrl.js", "pages/controllers/logViewerCtrl.js", "pages/controllers/appSettingsCtrl.js", "pages/controllers/pushNotificationCtrl.js", "pages/controllers/pushHistoryCtrl.js", "pages/controllers/pushGroupsCtrl.js", "pages/controllers/userProfileCtrl.js", "pages/controllers/bookmarkCtrl.js", "pages/controllers/notesCtrl.js", "pages/controllers/appSearchCtrl.js", "pages/controllers/installAppDialogCtrl.js", "pages/controllers/diagnosticsCtrl.js", "pages/services/stringResourceService.js", "pages/services/manifestService.js", "pages/services/sideMenuService.js", "scripts/framework/dynamicEngineService.js", "scripts/framework/appearanceHandler.js"],
            r = ["scripts/framework/richModal.js", "scripts/framework/carouselLight.js", "scripts/framework/pushNotifications.js", "scripts/framework/deviceEventHandlers.js", "scripts/framework/cache.js", "scripts/framework/pluginAPI/cameraAPI.js", "scripts/framework/pluginAPI/firebaseAPI.js", "scripts/framework/pluginAPI/mediaAPI.js", "scripts/framework/pluginAPI/actionItemsAPI.js", "scripts/framework/pluginAPI/componentUIAPI.js"],
            i = ["scripts/lib/angular.min.js", "scripts/lib/angular-route.min.js", "scripts/lib/angular-animate.min.js", "scripts/lib/ui-bootstrap.min.js", "scripts/lib/loading-bar.js", "scripts/lib/lodash.compat.js", "scripts/lib/minimongo.js", "scripts/lib/ng-file-upload-shim.min.js", "scripts/lib/ng-file-upload.min.js", "scripts/lib/fastclick.js", "scripts/lib/lory.min.js", "scripts/lib/scrollbooster.min.js", "scripts/lib/tinycolor-min.js", "scripts/lib/loggly.tracker.min.js"],
            o = ["scripts/lib/moment.min.js", "scripts/lib/exif.js", "scripts/lib/photoswipe.min.js", "scripts/lib/photoswipeui.min.js", "scripts/lib/hammer.2.0.4.js", "scripts/lib/wptr.1.1.js"],
            n = ["test/lib/jasmine-4.0.1/jasmine.min.js", "test/lib/jasmine-4.0.1/jasmine-html.js", "test/lib/jasmine-4.0.1/generators.js", "test/lib/jasmine-4.0.1/boot0.js", "test/lib/jasmine-4.0.1/boot1.js", "test/spec/SpecHelper.js", "test/spec/AppSessionSpec.js", "test/spec/PluginSessionSpec.js", "test/spec/AccountDeletionSpec.js", "test/spec/DynamicEngineSpec.js"],
            a = ["scripts/dynamic/dynamicEngine.min.js"],
            p = [],
            c = [{
                path: "styles/bootstrap.css",
                defer: !1
            }, {
                path: "styles/material-icons.css",
                defer: !1
            }, {
                path: "styles/auth.css",
                defer: !1
            }, {
                path: "styles/loading-bar.css",
                defer: !1
            }, {
                path: "styles/siteIcons.css",
                defer: !1
            }, {
                path: "styles/input.css",
                defer: !1
            }, {
                path: "styles/helper.css",
                defer: !1
            }, {
                path: "styles/transitionAnimation.css",
                defer: !1
            }, {
                path: "styles/appStyle.css",
                defer: !1
            }, {
                path: "styles/photoswipe.css",
                defer: !1
            }, {
                path: "styles/photoswipe.skin.css",
                defer: !1
            }, {
                path: "test/lib/jasmine-4.0.1/jasmine.css",
                defer: !1
            }];
        if (e) module.exports = {
            jsFiles: t,
            jsFilesDefer: r,
            jsVendorFiles: i,
            jsVendorDeferFiles: o,
            cssFiles: c.map((function(e) {
                return e.path
            }))
        };
        else try {
            ! function() {
                var e;
                "undefined" != typeof cordova && (window.bridge = cordova, window.bridge.capabilities = cordova.plugins, window.capabilities = window.plugins), (e = document.createElement("meta")).name = "viewport", e.content = "viewport-fit=cover, width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no", document.getElementsByTagName("head")[0].appendChild(e);
                var s = function(e) {
                        var s = localStorage.getItem(e);
                        if (s) try {
                            return JSON.parse(s)
                        } catch (e) {
                            return null
                        }
                    },
                    l = [];
                s(window.currentAppId + "-onboardingState") && (window.loadOnboarding = !1),
                    function() {
                        var e = s("currentAppManifest");
                        if (e)
                            if (l.push("manifestVersion:" + e.version), e.components && e.components.length)
                                for (var t = 0; t < e.components.length; t++) {
                                    var r = e.components[t];
                                    if (r) switch (r.name) {
                                        case "app":
                                        case "pluginScripts":
                                        case "pluginStyles":
                                            l.push(r.name + "Version:" + r.version);
                                            break;
                                        case "onboardingData":
                                            !1 !== window.loadOnboarding && e.hasOnboarding && r.isActive && (window.loadOnboarding = !0)
                                    }
                                } else l.push("noExistingManifest")
                    }();
                var u = function(e) {
                        var s, t = (null == e ? void 0 : e.message) || "This app is no longer active",
                            r = document.body,
                            i = document.head;
                        if (r && i) {
                            var o = document.createElement("meta");
                            o.name = "viewport", o.content = "viewport-fit=cover, width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no", i.appendChild(o);
                            var n = document.createElement("h2");
                            n.textContent = t, n.setAttribute("style", 'margin-top: 30vh;font-weight: 100; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica;'), r.setAttribute("style", "text-align: center;background-color: #eeeeee;"), r.innerHTML = "", r.appendChild(n)
                        }
                        null === (s = navigator.splashscreen) || void 0 === s || s.hide()
                    },
                    f = (location.hostname.indexOf("localhost") < 0 || location.search.toLowerCase().indexOf("forcemin") >= 0) && -1 == location.search.toLowerCase().indexOf("donotminify");

                function d(e, s, t, r, i, o) {
                    if (f) loadjs(e, {
                        success: function() {
                            i(), loadjs(s)
                        },
                        error: function(e) {
                            o(e)
                        },
                        async: !1
                    });
                    else {
                        for (var n = [], a = 0; a < t.length; a++) t[a] && n.push(g(t[a]));
                        loadjs(n, {
                            success: function() {
                                var e = [];
                                i();
                                for (var s = 0; s < r.length; s++) r[s] && e.push(g(r[s]));
                                loadjs(e)
                            },
                            error: function(e) {
                                o(e)
                            },
                            async: !1
                        })
                    }
                }

                function g(e) {
                    return 0 == e.indexOf("http") || 0 == e.indexOf("file") || 0 == e.indexOf("cdvfile") ? e : "".concat(window._appRoot).concat(e)
                }

                function m(e, s, t) {
                    var r = document.createElement("div");
                    e && (r.id = e), t && r.setAttribute("style", t), r.setAttribute("ng-include", s), document.body.appendChild(r)
                }
                window.getContentType = function(e) {
                    return e.indexOf(".css") > 0 ? "text/css" : e.indexOf(".js") > 0 ? "application/javascript" : e.indexOf(".html") > 0 ? "text/html" : e.indexOf(".svg") > 0 ? "image/svg+xml" : e.indexOf(".pdf") > 0 ? "application/pdf" : "text/plain"
                }, window.getAppContext = function() {
                    var e = window._getAppId() || 202,
                        s = window._getEnv() || "dev",
                        t = window._getLastUrl() || "",
                        r = window._getTrack() || null;
                    return new AppContext(e, s, i(window._getAppMode()), r, t, i(window._isPreview()));

                    function i(e) {
                        return "1" == e ? 1 : 0
                    }
                };
                var w = window.appContext = window.getAppContext(),
                    h = window._isTest();
                ! function() {
                    var e = function(e) {
                        var s = document.createElement("link");
                        s.href = window._appRoot + e, s.rel = "stylesheet", document.body.appendChild(s)
                    };
                    if (f) e("styles/all.min.css");
                    else
                        for (var s = 0; s < c.length; s++) {
                            var t = c[s];
                            t.defer || e(t.path)
                        }
                }(),
                function(e) {
                    var s = [],
                        t = function(e) {
                            var s = "";
                            switch (window._getEnv()) {
                                case "int":
                                    s = "https://s3-us-west-2.amazonaws.com/pluginserver/scripts/remoteOperations.js";
                                    break;
                                case "uat":
                                    s = "https://d1q5x1plk9guz6.cloudfront.net/scripts/remoteOperations.js";
                                    break;
                                case "prod":
                                    s = "https://pluginserver.buildfire.com/scripts/remoteOperations.js";
                                    break;
                                default:
                                    console.log("prod remoteOperations.js loaded ,  environment undefined "), s = "https://pluginserver.buildfire.com/scripts/remoteOperations.js"
                            }
                            return s
                        }();
                    if (s.push(t), window.location.protocol.indexOf("http") < 0 && currentAppId && "1" === window._getAppMode()) {
                        var r = "scripts/offline/" + currentAppId + ".js?cacheBuster=" + (new Date).getTime();
                        if (s.push(window._appRoot + r), window.loadOnboarding) {
                            var i = "scripts/offline/onboarding-" + currentAppId + "/onboarding.js?cacheBuster=" + (new Date).getTime();
                            s.push(window._appRoot + i)
                        } else window.loadOnboarding = !1
                    }
                    s && s.length > 0 ? loadjs(s, {
                        success: function() {
                            e()
                        },
                        error: function() {
                            e()
                        },
                        async: !1
                    }) : e()
                }((function() {
                    w.load((function() {
                        var e, s, c, l, f, g;
                        if (0 !== (null === (e = window.appContext) || void 0 === e || null === (s = e.currentApp) || void 0 === s || null === (c = s.config) || void 0 === c ? void 0 : c.isActive))
                            if (1 !== (null === (l = window.appContext) || void 0 === l || null === (f = l.currentApp) || void 0 === f || null === (g = f.config) || void 0 === g ? void 0 : g.isPaidApp) && window.appContext.liveMode) u({
                                message: "This app is no longer available"
                            });
                            else {
                                var w = window.siteConfig.endPoints.pluginRootHost;
                                window._appRoot && (w = window._appRoot + "../pluginTemplate");
                                var A = [window._appRoot + "scripts/vendor.min.js"];
                                a.forEach((function(e) {
                                    var s = "".concat(w, "/").concat(e);
                                    A.push(s), i.push(s)
                                }));
                                var j = [window._appRoot + "scripts/vendorDefer.min.js"];
                                p.forEach((function(e) {
                                    var s = "".concat(w, "/").concat(e);
                                    j.push(s), o.push(s)
                                }));
                                var v = [window._appRoot + "scripts/eager.min.js"],
                                    I = [window._appRoot + "scripts/defer.min.js"];
                                d(A, j, i, o, (function() {
                                    d(v, I, t, r, (function() {
                                        var e;
                                        ! function() {
                                            window.metrics = {
                                                _values: {},
                                                set: function(e, s) {
                                                    (bfUtils.isIOS || bfUtils.isAndroid) && (this._values[e] = s)
                                                },
                                                get: function(e) {
                                                    return this._values[e]
                                                },
                                                clear: function() {
                                                    this._values = {}
                                                },
                                                values: function() {
                                                    return this._values
                                                }
                                            };
                                            try {
                                                window.metrics.set("performanceLog", JSON.parse(localStorage.getItem("$$performance_log"))), window.metrics.set("indexStart", localStorage.getItem("$$index_page_start"))
                                            } catch (e) {
                                                console.error("error parsing $$performance_log: ".concat(e))
                                            } finally {
                                                localStorage.removeItem("$$performance_log"), localStorage.removeItem("$$index_page_start")
                                            }
                                        }(), m("appBody", "'" + window._appRoot + "body.html'", "height:100%"), m("login", "'" + window._appRoot + "fragments/auth/auth.html'"), m("menu", "'" + window._appRoot + "fragments/menu/menu.html'"), m("popup", "'" + window._appRoot + "fragments/popup/popup.html'"), m("footerMenu", "'" + window._appRoot + "fragments/footerMenu/footerMenu.html'"), m("userProfile", "'" + window._appRoot + "fragments/userProfile/userProfile.html'"), m("misc", "'" + window._appRoot + "fragments/misc/misc.html'"), m(null, "'" + window._appRoot + "pages/templates/pushSubscriptions.html'"), m(null, "'" + window._appRoot + "pages/templates/notes.html'"), h && function() {
                                            for (var e = [], s = 0; s < n.length; s++) e.push(window._appRoot + n[s]);
                                            loadjs(e, {
                                                success: function() {
                                                    console.log("SUCCESS JS TEST FILES")
                                                },
                                                error: function(e) {
                                                    console.error("ERROR JS TEST FILES", e)
                                                },
                                                async: !1
                                            })
                                        }(), (!window.appContext.currentApp || window.appContext.currentApp && 0 !== (null === (e = window.appContext.currentApp) || void 0 === e ? void 0 : e.config.isActive)) && (bfUtils.isMobileDevice ? document.addEventListener("deviceready", (function() {
                                            angular.element(document).ready((function() {
                                                angular.bootstrap(document, ["buildfire"])
                                            }))
                                        })) : angular.element(document).ready((function() {
                                            angular.bootstrap(document, ["buildfire"])
                                        })))
                                    }), (function(e) {
                                        console.error("could not load dependency", e)
                                    }))
                                }), (function(e) {
                                    console.error("could not load dependency", e)
                                }))
                            }
                        else u()
                    }))
                }))
            }()
        } catch (e) {
            console.error(JSON.stringify(e))
        }
    }();
"use strict";
var siteConfig = {
    dev: {
        endPoints: {
            appHost: "http://int2.myapp.buildfire.com",
            authHost: "http://int.auth.buildfire.com",
            pluginHost: "http://pluginserver.s3-website-us-west-2.amazonaws.com/plugins",
            pluginRootHost: "http://pluginserver.s3-website-us-west-2.amazonaws.com",
            socialHost: "http://int.social.kaleobusiness.com",
            push: "http://int.push.buildfire.com",
            datastoreHost: "http://int2.ds.buildfire.com:88",
            analyticsHost: "http://int2.myapp.buildfire.com:2400",
            crmHost: "http://int2.myapp.buildfire.com:129",
            pushV2: "http://uat.push2.buildfire.com:8001",
            hopHost: "https://public.buildfire.com/1.0/hop",
            publicFilesHost: "http://localhost:88",
            searchEngineHost: "https://l9lilzp827.execute-api.us-east-1.amazonaws.com/UAT",
            creditSystemHost: "https://l9lilzp827.execute-api.us-east-1.amazonaws.com/UAT",
            gatewayHost: "https://l9lilzp827.execute-api.us-east-1.amazonaws.com/UAT",
            cloudImageHost: "https://acbbesnfco.cloudimg.io/v7",
            aiChatApiUrl: "https://6ywtaqp22v64u4cpiwhnw3ebre0cduhp.lambda-url.us-east-1.on.aws"
        }
    },
    int: {
        endPoints: {
            appHost: "http://int2.myapp.buildfire.com",
            authHost: "http://int.auth.buildfire.com",
            pluginHost: "http://pluginserver.s3-website-us-west-2.amazonaws.com/plugins",
            pluginRootHost: "http://pluginserver.s3-website-us-west-2.amazonaws.com",
            socialHost: "http://int.social.kaleobusiness.com",
            push: "http://int.push.buildfire.com",
            datastoreHost: "http://int2.ds.buildfire.com:88",
            analyticsHost: "http://int2.myapp.buildfire.com:2400",
            crmHost: "http://int2.myapp.buildfire.com:129",
            pushV2: "http://uat-push2.buildfire.com:8001",
            hopHost: "https://public.buildfire.com/1.0/hop",
            publicFilesHost: "http://int2.ds.buildfire.com:88",
            searchEngineHost: "https://l9lilzp827.execute-api.us-east-1.amazonaws.com/UAT",
            creditSystemHost: "https://l9lilzp827.execute-api.us-east-1.amazonaws.com/UAT",
            gatewayHost: "https://l9lilzp827.execute-api.us-east-1.amazonaws.com/UAT",
            cloudImageHost: "https://acbbesnfco.cloudimg.io/v7",
            aiChatApiUrl: "https://6ywtaqp22v64u4cpiwhnw3ebre0cduhp.lambda-url.us-east-1.on.aws"
        }
    },
    uat: {
        endPoints: {
            appHost: "https://uat-app.buildfire.com",
            authHost: "https://uat-auth.buildfire.com",
            pluginHost: "https://d1q5x1plk9guz6.cloudfront.net/plugins",
            pluginRootHost: "https://d1q5x1plk9guz6.cloudfront.net",
            socialHost: "https://uat-social.buildfire.com",
            push: "https://uat-push.buildfire.com",
            datastoreHost: "https://uat-ds.buildfire.com",
            analyticsHost: "https://uat-analytics.buildfire.com",
            crmHost: "https://uat-crm.buildfire.com",
            pushV2: "https://uat-push2.buildfire.com",
            hopHost: "https://public.buildfire.com/1.0/hop",
            publicFilesHost: "https://uat-fileserver.buildfire.com",
            searchEngineHost: "https://l9lilzp827.execute-api.us-east-1.amazonaws.com/UAT",
            creditSystemHost: "https://l9lilzp827.execute-api.us-east-1.amazonaws.com/UAT",
            gatewayHost: "https://l9lilzp827.execute-api.us-east-1.amazonaws.com/UAT",
            cloudImageHost: "https://acbbesnfco.cloudimg.io/v7",
            aiChatApiUrl: "https://6ywtaqp22v64u4cpiwhnw3ebre0cduhp.lambda-url.us-east-1.on.aws"
        },
        tracks: {
            1: [{
                name: "pluginHost",
                value: "https://d1q5x1plk9guz6.cloudfront.net/plugins"
            }, {
                name: "pluginRootHost",
                value: "https://d1q5x1plk9guz6.cloudfront.net"
            }],
            2: [{
                name: "pluginHost",
                value: "https://d3lkxgii6udy4q.cloudfront.net/plugins"
            }, {
                name: "pluginRootHost",
                value: "https://d3lkxgii6udy4q.cloudfront.net"
            }],
            3: [{
                name: "pluginHost",
                value: "https://d26kqod42fnsx0.cloudfront.net/plugins"
            }, {
                name: "pluginRootHost",
                value: "https://d26kqod42fnsx0.cloudfront.net"
            }]
        }
    },
    beta: {
        endPoints: {
            appHost: "https://beta-app.buildfire.com",
            authHost: "https://auth.buildfire.com",
            pluginHost: "https://pluginserver.buildfire.com/plugins",
            pluginRootHost: "https://pluginserver.buildfire.com",
            socialHost: "https://social.buildfire.com",
            push: "https://push.buildfire.com",
            datastoreHost: "https://datastore.buildfire.com",
            analyticsHost: "https://analytics.buildfire.com",
            crmHost: "https://crm.buildfire.com",
            pushV2: "https://push2.buildfire.com",
            hopHost: "https://public.buildfire.com/1.0/hop",
            publicFilesHost: "https://publicfiles.buildfire.com",
            searchEngineHost: "https://public.buildfire.com/1.0",
            creditSystemHost: "https://public.buildfire.com/1.0",
            gatewayHost: "https://public.buildfire.com/1.0",
            cloudImageHost: "https://acbbesnfco.cloudimg.io/v7",
            aiChatApiUrl: "https://52aeg5uhofwhz3solhfxdzx6he0pmaxd.lambda-url.us-east-1.on.aws"
        }
    },
    prod: {
        endPoints: {
            appHost: "https://app.buildfire.com",
            authHost: "https://auth.buildfire.com",
            pluginHost: "https://pluginserver.buildfire.com/plugins",
            pluginRootHost: "https://pluginserver.buildfire.com",
            socialHost: "https://social.buildfire.com",
            push: "https://push.buildfire.com",
            datastoreHost: "https://datastore.buildfire.com",
            analyticsHost: "https://analytics.buildfire.com",
            crmHost: "https://crm.buildfire.com",
            pushV2: "https://push2.buildfire.com",
            hopHost: "https://public.buildfire.com/1.0/hop",
            publicFilesHost: "https://publicfiles.buildfire.com",
            searchEngineHost: "https://public.buildfire.com/1.0",
            creditSystemHost: "https://public.buildfire.com/1.0",
            gatewayHost: "https://public.buildfire.com/1.0",
            cloudImageHost: "https://acbbesnfco.cloudimg.io/v7",
            aiChatApiUrl: "https://52aeg5uhofwhz3solhfxdzx6he0pmaxd.lambda-url.us-east-1.on.aws"
        }
    }
};
! function() {
    var t = window._getEnv(),
        s = window._getTrack();
    null == t && (0 === window.location.host.lastIndexOf("localhost", 0) ? (t = "uat", console.error("Specify the environment; e.g. localhost?env=prod. Defaulting to uat.")) : t = function(t) {
        var s;
        switch (t) {
            case "uat-app":
                s = "uat";
                break;
            case "int":
            case "int2":
                s = "int";
                break;
            case "beta-app":
                s = "beta";
                break;
            default:
                s = "prod"
        }
        return s
    }(window.location.host.split(".")[0]));
    ! function(t, s) {
        switch (t) {
            case "int":
                window.siteConfig = siteConfig.int;
                break;
            case "uat":
                var i = siteConfig.uat;
                if (s)(i.tracks[s] || []).forEach((function(t) {
                    var s = t.name,
                        o = t.value;
                    i.endPoints[s] = o
                })), delete i.tracks;
                window.siteConfig = i;
                break;
            case "beta":
                window.siteConfig = siteConfig.beta;
                break;
            case "prod":
                window.siteConfig = siteConfig.prod;
                break;
            default:
                window.siteConfig = siteConfig.prod, console.error("app pointing to PROD")
        }
        window.siteConfig.scope = "app"
    }(t, s)
}();